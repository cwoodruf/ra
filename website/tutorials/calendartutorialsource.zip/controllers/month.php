<?php
/**
 * Display a month calendar using the Calendar view class
 */
class Month extends Controller {
    public function execute() {

        // get the date input from the date input widgets on the calendar
        $start = Calendar::startdate();

        // the events array and calendar use dates in the format of YYYY-MM-DD
        $yesterday = date('Y-m-d',time() - 86400); 

        $events = array(
             $yesterday => 'previous event',
             $start => 'event for start',
        );
        View::assign('events',$events);
        View::assign('showevents','plainevent.tpl');
	View::addCSS('calendar.css');
        Calendar::showmonth('month.tpl');
    }
}
