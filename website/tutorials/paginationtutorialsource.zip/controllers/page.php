<?php
/*
 * this is a demo of the paging tools
 */
class Page extends Controller {
        const PAGESIZE = 10; // this could also be set from CGI parameters

        public function execute() {

                # use the remembered state to get the correct page
                if (!isset($_REQUEST['offset']))
                        $offset = Entity::getpageid('numbered','offset');
                else
                        $offset = $_REQUEST['offset'];

                # how to get a page of records from the db
                $page = Entity::getpage(
                        'numbered',
                        (new Numbered),
                        $offset,
                        self::PAGESIZE,
                        'order by created desc',
                        array('*',"length(notes) as characters")
                );

                # these are needed by the pagerlinks plugin 
                View::assign('limit',$page['limit']);
                View::assign('howmany',$page['howmany']);
                View::assign('offset',$page['offset']);
                View::assign('notes',$page['rows']);

                View::wrap('page.tpl');
        }
}

