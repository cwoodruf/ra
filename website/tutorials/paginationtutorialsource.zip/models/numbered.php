<?php
class Numbered extends NumberedEntity {
}

