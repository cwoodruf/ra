<?php
# copy this file to .salt.php and change the SALT to improve security for the database
# the salt value is used in Login::encode($pw) which provides a basic encoding method for
# passwords - however you can encode them any way you want
define('SALT','ce465bdaaee22c0ed0a851043f81037c8e941644');
